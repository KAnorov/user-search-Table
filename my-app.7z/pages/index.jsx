import GetUsers from "@/components/Users/GetUsers";

export default function Home() {
  return <>
     <GetUsers />
  </>
}
